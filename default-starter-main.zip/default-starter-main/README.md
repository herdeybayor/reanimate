# Default Starter

Clone this repo and run `yarn install` to install all the dependencies :)

### Need additional dependencies? 

```bash
npx expo install (package-name)
```
