import { App } from './src';

// eslint-disable-next-line import/no-default-export
export default App;
